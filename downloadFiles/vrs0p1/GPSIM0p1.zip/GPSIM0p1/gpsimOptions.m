function options = gpsimOptions

% GPSIMOPTIONS Creates a set of default options for a GPSIM model.
%
%	Description:
%
%	OPTIONS = GPSIMOPTIONS returns a default options stucture for a
%	GPSIM model.
%	 Returns:
%	  OPTIONS - the options structure.
%	
%
%	See also
%	GPSIMCREATE


%	Copyright (c) 2006 Neil D. Lawrence
% 	gpsimOptions.m version 1.1


options.optimiser = 'conjgrad';
options.includeNoise = 0;