function model = gpsimUpdateKernels(model)

% GPSIMUPDATEKERNELS Updates the kernel representations in the GPSIM structure.
%
%	Description:
%
%	MODEL = GPSIMUPDATEKERNELS(MODEL) updates any representations of the
%	kernel in the model structure, such as invK, logDetK or K.
%	 Returns:
%	  MODEL - the model structure with the kernels updated.
%	 Arguments:
%	  MODEL - the model structure for which kernels are being updated.
%	
%
%	See also
%	% SEEALSO GPSIMEXPANDPARAM, GPSIMCREATE


%	Copyright (c) 2006 % COPYRIGHT Neil D. Lawrence
% 	gpsimUpdateKernels.m version 1.1


model.K = real(kernCompute(model.kern, model.t)+diag(model.yvar));
[model.invK, U] = pdinv(model.K);
model.logDetK = logdet(model.K, U);