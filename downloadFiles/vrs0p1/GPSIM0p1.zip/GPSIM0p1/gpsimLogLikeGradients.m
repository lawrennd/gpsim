function g = gpsimLogLikeGradients(model)

% GPSIMLOGLIKEGRADIENTS Compute the gradients of the log likelihood of a GPSIM model.
%
%	Description:
%
%	G = GPSIMLOGLIKEGRADIENTS(MODEL) computes the gradients of the log
%	likelihood of the given Gaussian process for use in a single input
%	motif protein network.
%	 Returns:
%	  G - the gradients of the parameters of the model.
%	 Arguments:
%	  MODEL - the model for which the log likelihood is computed.
%	
%
%	See also
%	GPSIMCREATE, GPSIMLOGLIKELIHOOD, GPSIMGRADIENT


%	Copyright (c) 2006 Neil D. Lawrence
% 	gpsimLogLikeGradients.m version 1.1


covGrad = -model.invK + model.invK*model.m*model.m'*model.invK;
covGrad = 0.5*covGrad;
g = kernGradient(model.kern, model.t, covGrad);



gmuFull = model.m'*model.invK;
numData = size(model.t, 1);
ind = 1:numData;
gmu = zeros(size(1, model.numGenes));
for i = 1:model.numGenes
  gmu(i) = sum(gmuFull(ind));
  ind = ind + numData;
end
gb = gmu./model.D;
fhandle = str2func([model.bTransform 'Transform']);
gb = gb.*fhandle(model.B, 'gradfact');

% This is a nasty hack to add the influence of the D in the mean to
% the gradient already computed for the kernel. This is all very
% clunky and sensitive to changes that take place elsewhere in the
% code ...
gd = -gmu.*model.B./(model.D.*model.D);
if model.kern.numBlocks == 1
  decayIndices = 1;
elseif model.kern.numBlocks>1
  decayIndices = [1 4];
  for i = 3:model.kern.numBlocks
    decayIndices(end+1) = decayIndices(end) + 2;
  end
end
g(decayIndices) = g(decayIndices) ...
    + gd.*negLogLogitTransform(model.D, 'gradfact');

g = [g gb];

if isfield(model, 'fix')
  for i = 1:length(model.fix)
    g(model.fix(i).index) = 0;
  end
end
