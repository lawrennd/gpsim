% GPSIM toolbox
% Version 0.1		Saturday 13 May 2006 at 18:11
% Copyright (c) 2006 Neil D. Lawrence
% 
% GPSIMEXTRACTPARAM Extract the parameters of a GPSIM model.
% GPSIMCREATE Create a GPSIM model.
% GPSIMLOGLIKEGRADIENTS Compute the gradients of the log likelihood of a GPSIM model.
% GPSIMDISPLAY Display a Gaussian process model.
% DEMBARENCO1 Run experiments on data from Barenco et al in Genome Biology.
% GPSIMUPDATEKERNELS Updates the kernel representations in the GPSIM structure.
% GPSIMLOGLIKELIHOOD Compute the log likelihood of a GPSIM model.
% CGPSIMLOGLIKELIHOOD Compound GPSIM model's log likelihood.
% CGPSIMLOGLIKEGRADIENTS Compound GPSIM model's gradients.
% GPSIMGRADIENT Gradient wrapper for a GPSIM model.
% CGPSIMEXPANDPARAM Expand params into model structure.
% GPSIMOPTIMISE Optimise the GPSIM model.
% CGPSIMEXTRACTPARAM Extract parameters from compound GPSIM model.
% GPSIMEXPANDPARAM Expand the given parameters into a GPSIM structure.
% GPSIMOBJECTIVE Wrapper function for GPSIM objective.
% GPSIMTEST Test the single input motif code.
% GPSIMOPTIONS Creates a set of default options for a GPSIM model.
