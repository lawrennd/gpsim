function I = drosGetGeneinds(drosdata, genes),

% DROSGETGENEINDS returns indices of given genes in the given data
%
%	Description:
%	
%	Usage:
%	I = drosGetGeneinds(drosdata, genes)


%	Copyright (c) 2007 Antti Honkela
% 	drosGetGeneinds.m version 1.1


I = [];

for k=1:length(genes),
  I = [I, find(strcmp(genes{k}, drosdata.genes))];
end
