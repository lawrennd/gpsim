function y = gpsimArtificialGenes(t, alpha, mu, sigma, B, S, D)

% GPSIMARTIFICIALGENES Give artifical genes from given parameters.
%
%	Description:
%	y = gpsimArtificialGenes(t, alpha, mu, sigma, B, S, D)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	gpsimArtificialGenes.m version 1.2


y = zeros(length(t), length(B));

for i = 1:length(B)
  y(:, i) = B(i)/D(i);
  D2 = D(i)*D(i);
  for j = 1:length(alpha)
    sigma2 = sigma(j)*sigma(j);
%    y(:, i) = y(:, i) + S(i)*sigma(j)*alpha(j)*sqrt(pi)...
%              *exp(D2*sigma2/4 - D(i)*(t-mu(j))) ...
%              .*(-cumGaussian(-2/sqrt(2)*(t - D(i)/2*sigma2 - mu(j))/sigma(j)) ...
%                +cumGaussian(2/sqrt(2)*(D(i)/2*sigma2 + mu(j))/sigma(j)));
    y(:, i) = y(:, i) + exp(log(S(i)*sigma(j)*alpha(j)*sqrt(pi))...
              +(D2*sigma2/4 - D(i)*(t-mu(j))) ...
              +lnDiffCumGaussian(repmat(2/sqrt(2)*(D(i)/2*sigma2 + ...
                                            mu(j))/sigma(j), ...
                                        size(t, 1), size(t, 2)),...
                                 -2/sqrt(2)*(t - D(i)/2*sigma2 - ...
                                                    mu(j))/sigma(j)));
  end
end
