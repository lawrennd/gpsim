
% GPSIMTOOLBOXES Toolboxes for the GPSIM software.
%
%	Description:
%	

%	Copyright (c) 2007 Neil D. Lawrence
% 	gpsimToolboxes.m version 1.4

importLatest('netlab');
importLatest('optimi');
importLatest('ndlutil');
importLatest('mltools');
importLatest('kern');
importLatest('fgplvm');
