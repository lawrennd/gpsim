function [model, ll] = gpsimMapUpdateF(model, options)

% GPSIMMAPUPDATEF Update posterior mean of f.
%
%	Description:
%
%	[MODEL, LL] = GPSIMMAPUPDATEF(MODEL, OPTIONS) updates the stored
%	version of the posterior mean for f in the GPSIMMAP model.
%	 Returns:
%	  MODEL - the model with f updated.
%	  LL - the log likelihood after update.
%	 Arguments:
%	  MODEL - the model for which f is to be updated.
%	  OPTIONS - options vector.
%	gpsimMapFunctionalLogLikeHessian, gpsimMapCreate
%	
%
%	See also
%	GPSIMMAPFUNCTIONALLOGLIKEGRADIENT, 


%	Copyright (c) 2006 Neil D. Lawrence
% 	gpsimMapUpdateF.m version 1.3


display = options(1);
tolf = options(2);
tol = options(3);
iters = options(14);
if iters == 0
  iters = 100;
end
f = gpsimMapFunctionalExtractParam(model);
llold = gpsimMapFunctionalLogLikelihood(model);

%if model.isConcave
  for i = 1:iters
    ll = llold - 1;
    gf = gpsimMapFunctionalLogLikeGradients(model);
    new_drn = (model.covf*gf')';
    factor = 1;
    count = 0;
    fold = f;
    while ll < llold 
      f = fold + factor*new_drn;
      model = gpsimMapFunctionalExpandParam(model, f);
      ll = gpsimMapFunctionalLogLikelihood(model);
      lldiff = ll - llold;
      count = count + 1;
      if count > 1 & display
        fprintf('gpsimMapUpdateF, lldiff: %2.4f, factor %2.4f\n', lldiff, factor);
      end
      factor = factor/2;
    end
    if lldiff < tol %& max(abs(fold - f))<tolf
      break
    end
    if display
      fprintf('Iteration %d, log likelihood %2.4f\n', i, ll);
    end
    llold = ll;
  end
%else
%  error('Not yet implemented non-concave update')
%end