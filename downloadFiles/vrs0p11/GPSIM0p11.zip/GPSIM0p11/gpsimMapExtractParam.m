function [param, names] = gpsimMapExtractParam(model)

% GPSIMMAPEXTRACTPARAM Extract the parameters of a GPSIMMAP model.
%
%	Description:
%
%	PARAMS = GPSIMMAPEXTRACTPARAM(MODEL) extracts the model parameters
%	from a structure containing the information about a Gaussian process
%	for single input motif modelling.
%	 Returns:
%	  PARAMS - a vector of parameters from the model.
%	 Arguments:
%	  MODEL - the model structure containing the information about the
%	   model.
%	
%
%	See also
%	GPSIMMAPCREATE, GPSIMMAPEXPANDPARAM, MODELEXTRACTPARAM


%	Copyright (c) 2006 Neil D. Lawrence
% 	gpsimMapExtractParam.m version 1.2


if nargout>1
  [param, names] = kernExtractParam(model.kern);
else
  param = kernExtractParam(model.kern);
end

if isfield(model, 'fix')
  for i = 1:length(model.fix)
    param(model.fix(i).index) = model.fix(i).value;
  end
end
param = real(param);

% Check if there is a mean function.
if isfield(model, 'meanFunction') & ~isempty(model.meanFunction)
  if nargout>1
    [meanFuncParams, meanFuncNames] = modelExtractParam(model.meanFunction);
  else
    meanFuncParams = modelExtractParam(model.meanFunction);
  end
else
  meanFuncParams =[];
  meanFuncNames = [];
end

param = [param meanFuncParams];
if nargout > 1
  names = {names{:} meanFuncNames{:}};
end