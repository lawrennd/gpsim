% GPSIM toolbox
% Version 0.11		Saturday 06 Jan 2007 at 00:06
% Copyright (c) 2007 Neil D. Lawrence
% 
% EXPVARMEANCREATE Creates an the mean function for the EXP kernel.
% GPSIMEXTRACTPARAM Extract the parameters of a GPSIM model.
% GPSIMMAPEXPANDPARAM Expand the given parameters into a GPSIMMAP structure.
% GPSIMMAPUPDATEPOSTERIORCOVARIANCE update the posterior covariance of f.
% GPSIMMAPFUNCTIONALLOGLIKELIHOOD Compute the log likelihood of a GPSIMMAP model.
% EXPVARMEANEXTRACTPARAM Extract weights and biases from an EXPVARMEAN mapping.
% GPSIMMAPCREATE Create a GPSIMMAP model.
% GPSIMCREATE Create a GPSIM model.
% EXPVARMEANOUT Output of an EXPVARMEAN model.
% GPSIMMAPUPDATEKERNELS Updates the kernel representations in the GPSIMMAP structure.
% GPSIMLOGLIKEGRADIENTS Compute the gradients of the log likelihood of a GPSIM model.
% GPSIMMAPBARENCORESULTS Plot the results from the MAP script.
% GPSIMMAPLOGLIKELIHOOD Compute the log likelihood of a GPSIMMAP model.
% DEMBARENCOVARIATIONAL1 Optimise model using variational approximation with RBF kernel and exponential response.
% GPSIMDISPLAY Display a Gaussian process model.
% DEMTOYPROBLEM1 Generate an artifical data set and solve with GPSIM.
% DEMBARENCO1 Run experiments on data from Barenco et al in Genome Biology.
% GPSIMMAPFUNCTIONALEXTRACTPARAM Extract the function values from a GPSIMMAP model.
% GPSIMUPDATEKERNELS Updates the kernel representations in the GPSIM structure.
% GPSIMLOGLIKELIHOOD Compute the log likelihood of a GPSIM model.
% DEMBARENCOMAP1 Optimise model using MAP approximation with RBF kernel and linear response.
% DEMBARENCOMAP2 Optimise model using MAP approximation with MLP kernel and linear response.
% DEMBARENCOMAP3 Optimise model using MAP approximation with RBF kernel and exp response.
% DEMBARENCOMAP4 Optimise model using MAP approximation with MLP kernel and exp response.
% DEMBARENCOMAP5 Optimise model using MAP approximation with RBF kernel and negLogLogit response.
% DEMBARENCOMAP6 Optimise model using MAP approximation with MLP kernel and negLogLogit response.
% DEMBARENCOMAP7 Optimise model using MAP approximation with RBF kernel and sigmoid response.
% DEMBARENCOMAP8 Optimise model using MAP approximation with MLP kernel and negLogLogit response.
% CGPSIMLOGLIKELIHOOD Compound GPSIM model's log likelihood.
% GPSIMMAPOPTIONS Creates a set of default options for a GPSIMMAP model.
% GPSIMMAPFUNCTIONALLOGLIKEGRADIENTS Compute the functional gradient for GPSIMMAP.
% EXPVARMEANEXPANDPARAM Update expvarMean mapping with new vector of parameters.
% GPSIMMAPFUNCTIONALUPDATEW Update the data component of the Hessian.
% GPSIMMAPUPDATEF Update posterior mean of f.
% GPSIMMAPUPDATEG Update the nonlinear transformation of f.
% CGPSIMLOGLIKEGRADIENTS Compound GPSIM model's gradients.
% GPSIMARTIFICIALPROTEIN Generate an artifical protein sequence.
% GPSIMGRADIENT Gradient wrapper for a GPSIM model.
% GPSIMMAPFUNCTIONALLOGLIKEHESSIAN Compute the functional Hessian for GPSIMMAP.
% GPSIMMAPEXTRACTPARAM Extract the parameters of a GPSIMMAP model.
% GPSIMMAPFUNCTIONALEXPANDPARAM Expand the given function values into a GPSIMMAP structure.
% CGPSIMEXPANDPARAM Expand params into model structure.
% GPSIMOPTIMISE Optimise the GPSIM model.
% GPSIMLOADBARENCODATA Load in Martino Barenco's data as processed by mmgMOS.
% CGPSIMEXTRACTPARAM Extract parameters from compound GPSIM model.
% GPSIMARTIFICIALGENES Give artifical genes from given parameters.
% GPSIMEXPANDPARAM Expand the given parameters into a GPSIM structure.
% GPSIMMAPTEST Tests the gradients of the GPSIMMAP model.
% GPSIMMAPUPDATEYPRED Update the stored numerical prediction for y.
% GPSIMMAPLOGLIKEGRADIENTS Compute the gradients of the log likelihood of a GPSIMMAP model.
% GPSIMOBJECTIVE Wrapper function for GPSIM objective.
% GPSIMTEST Test the single input motif code.
% GPSIMOPTIONS Creates a set of default options for a GPSIM model.
