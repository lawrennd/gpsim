function param = cgpsimExtractParam(model)

% CGPSIMEXTRACTPARAM Extract parameters from compound GPSIM model.
%
%	Description:
%
%	PARAM = CGPSIMEXTRACTPARAM(MODEL) this is just a wrapper for
%	learning three GP models simultaneously.
%	 Returns:
%	  PARAM - parameters extracted from the model.
%	 Arguments:
%	  MODEL - input model from which parameters will be extracted.
%	
%
%	See also
%	GPSIMEXTRACTPARAM


%	Copyright (c) 2006 Neil D. Lawrence
% 	cgpsimExtractParam.m version 1.1


param = gpsimExtractParam(model.comp{1});
