function genes = drosFindTargets(droschip),

% DROSFINDTARGETS returns a sorted list of targets
%
%	Description:
%	
%	Usage:
%	genes = drosFindTargets(droschip)


%	Copyright (c) 2008 Antti Honkela
% 	drosFindTargets.m version 1.1


[foo, I] = sort(-sum(droschip.data ~= 0, 2));
genes = droschip.genes(I);
